import React from "react";
import { INTERESTS, interestById } from "./data";

export function InterestTag({ id, highlighted = false, size = "md" }) {
  const interest = interestById(id);
  if (!interest) return null;
  const sizes = {
    sm: "text-xs px-2.5 py-1",
    md: "text-sm px-3 py-1.5",
  };
  const base = `inline-flex items-center gap-1.5 rounded-pill font-medium ${sizes[size]}`;
  if (highlighted) {
    return (
      <span className={`${base} bg-coral/15 text-coral border border-coral/30`}>
        <span>{interest.emoji}</span>
        <span>{interest.label}</span>
      </span>
    );
  }
  return (
    <span className={`${base} bg-teal/15 text-teal border border-teal/25`}>
      <span>{interest.emoji}</span>
      <span>{interest.label}</span>
    </span>
  );
}

export function Avatar({ src, name, size = 56, ring = false }) {
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("");
  return (
    <div
      className={`shrink-0 overflow-hidden rounded-full bg-canvas/80 flex items-center justify-center font-heading font-bold text-ink/60 ${
        ring ? "ring-2 ring-coral/40 ring-offset-2 ring-offset-canvas" : ""
      }`}
      style={{ width: size, height: size }}
    >
      {src ? (
        <img src={src} alt={name} className="w-full h-full object-cover" />
      ) : (
        <span style={{ fontSize: size * 0.36 }}>{initials}</span>
      )}
    </div>
  );
}

export function TopBar({ title, onBack, right }) {
  return (
    <header className="sticky top-0 z-20 bg-canvas/85 backdrop-blur-md border-b border-ink/5">
      <div className="flex items-center justify-between px-5 h-14">
        <div className="flex items-center gap-2 min-w-0">
          {onBack && (
            <button
              onClick={onBack}
              className="w-9 h-9 -ml-1 flex items-center justify-center rounded-full text-ink/70 hover:bg-ink/5 active:scale-95 transition"
              aria-label="Back"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
          )}
          <h1 className="font-heading font-bold text-lg text-ink truncate">{title}</h1>
        </div>
        {right}
      </div>
    </header>
  );
}

export function EmptyState({ emoji, title, subtitle }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 px-8">
      <div className="text-5xl mb-4">{emoji}</div>
      <h2 className="font-heading font-bold text-lg text-ink mb-1.5">{title}</h2>
      <p className="text-sm text-ink/55 max-w-xs">{subtitle}</p>
    </div>
  );
}
