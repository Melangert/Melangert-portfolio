import React, { useState } from "react";
import { PEOPLE, interestById } from "../data";
import { Avatar, EmptyState } from "../components";

export default function Matches({ connections, onOpenChat }) {
  const matched = PEOPLE.filter((p) => connections[p.id] === "matched");

  const [activeChat, setActiveChat] = useState(null);

  if (activeChat) {
    return (
      <ChatThread
        person={activeChat}
        onBack={() => setActiveChat(null)}
      />
    );
  }

  return (
    <div className="min-h-full bg-canvas">
      <header className="sticky top-0 z-20 bg-canvas/85 backdrop-blur-md border-b border-ink/5">
        <div className="px-5 pt-4 pb-3">
          <p className="text-xs text-ink/45 font-medium">Your connections</p>
          <h1 className="font-heading font-extrabold text-2xl text-ink tracking-tight">
            Inbox
          </h1>
        </div>
      </header>

      <div className="px-4 pt-3 pb-24 app-scroll overflow-y-auto">
        {matched.length === 0 ? (
          <EmptyState
            emoji="💬"
            title="No matches yet"
            subtitle="Connect with people in Discover to start chatting. Matches show up here with a friendly opening line."
          />
        ) : (
          <div className="space-y-2.5">
            {matched.map((person, idx) => {
              const topShared = person.sharedInterests?.[0];
              const interest = topShared ? interestById(topShared) : null;
              return (
                <button
                  key={person.id}
                  onClick={() => setActiveChat(person)}
                  className="w-full text-left bg-white rounded-2xl p-3.5 shadow-soft border border-ink/5 flex items-center gap-3 active:scale-[0.99] transition animate-fade-up"
                  style={{ animationDelay: `${idx * 0.04}s` }}
                >
                  <Avatar src={person.avatar} name={person.name} size={52} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h2 className="font-heading font-bold text-[0.95rem] text-ink truncate">
                        {person.name}
                      </h2>
                      <span className="text-[11px] text-ink/40 shrink-0">
                        {person.time}
                      </span>
                    </div>
                    {interest && (
                      <p className="text-xs text-coral font-medium mt-0.5">
                        You both love {interest.emoji} {interest.label} — say hi!
                      </p>
                    )}
                    <p className="text-xs text-ink/55 mt-0.5 truncate">
                      {person.message}
                    </p>
                  </div>
                  {person.unread && (
                    <span className="w-2.5 h-2.5 rounded-full bg-coral shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function ChatThread({ person, onBack }) {
  const [messages, setMessages] = useState([
    { from: "them", text: person.message, time: person.time },
  ]);
  const [draft, setDraft] = useState("");

  const send = () => {
    if (!draft.trim()) return;
    setMessages((prev) => [
      ...prev,
      { from: "me", text: draft.trim(), time: "now" },
    ]);
    setDraft("");
  };

  const topShared = person.sharedInterests?.[0];
  const interest = topShared ? interestById(topShared) : null;

  return (
    <div className="min-h-full bg-canvas flex flex-col">
      <header className="sticky top-0 z-20 bg-canvas/85 backdrop-blur-md border-b border-ink/5">
        <div className="flex items-center gap-3 px-4 h-16">
          <button
            onClick={onBack}
            className="w-9 h-9 flex items-center justify-center rounded-full text-ink/70 hover:bg-ink/5 active:scale-95 transition"
            aria-label="Back"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </button>
          <Avatar src={person.avatar} name={person.name} size={40} />
          <div className="min-w-0">
            <h1 className="font-heading font-bold text-base text-ink truncate">
              {person.name}
            </h1>
            {interest && (
              <p className="text-xs text-coral font-medium truncate">
                {interest.emoji} {interest.label} in common
              </p>
            )}
          </div>
        </div>
      </header>

      {interest && (
        <div className="mx-4 mt-3 bg-coral/10 rounded-2xl p-3 text-center animate-fade-up">
          <p className="text-sm text-coral font-semibold">
            {person.matchPrompt}
          </p>
        </div>
      )}

      <div className="flex-1 px-4 py-4 space-y-2.5 app-scroll overflow-y-auto">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex ${m.from === "me" ? "justify-end" : "justify-start"} animate-fade-up`}
          >
            <div
              className={`max-w-[75%] px-3.5 py-2.5 rounded-2xl text-sm leading-snug ${
                m.from === "me"
                  ? "bg-coral text-white rounded-br-md"
                  : "bg-white text-ink rounded-bl-md shadow-soft border border-ink/5"
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
      </div>

      <div className="sticky bottom-0 bg-canvas/95 backdrop-blur-md border-t border-ink/5 px-4 py-3">
        <div className="flex items-center gap-2 bg-white rounded-pill pl-4 pr-1.5 py-1.5 shadow-soft border border-ink/5">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Say hi…"
            className="flex-1 bg-transparent text-sm text-ink placeholder:text-ink/35 focus:outline-none"
          />
          <button
            onClick={send}
            disabled={!draft.trim()}
            className={`w-9 h-9 flex items-center justify-center rounded-full transition active:scale-90 ${
              draft.trim() ? "bg-coral text-white" : "bg-ink/10 text-ink/30"
            }`}
            aria-label="Send"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
