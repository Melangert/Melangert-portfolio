import React, { useState } from "react";
import { INTERESTS } from "../data";

export default function Onboarding({ onStart }) {
  const [selected, setSelected] = useState([]);
  const [animKey, setAnimKey] = useState(0);

  const toggle = (id) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
    setAnimKey((k) => k + 1);
  };

  const canStart = selected.length >= 1;

  return (
    <div className="min-h-full flex flex-col bg-canvas">
      <div className="flex-1 app-scroll overflow-y-auto px-5 pt-12 pb-28">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-pill bg-coral/10 text-coral text-xs font-semibold mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-coral" />
            Step 1 of 1
          </div>
          <h1 className="font-heading font-extrabold text-[2rem] leading-[1.15] text-ink tracking-tight">
            What are you
            <br />
            <span className="text-coral">into?</span>
          </h1>
          <p className="text-ink/55 text-sm mt-2 max-w-[16rem]">
            Pick a few things you love. We'll find people nearby who share them.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2.5 mt-7">
          {INTERESTS.map((interest) => {
            const on = selected.includes(interest.id);
            return (
              <button
                key={interest.id}
                onClick={() => toggle(interest.id)}
                className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center gap-1.5 p-2 transition-all duration-200 active:scale-95 ${
                  on
                    ? "bg-coral text-white shadow-card"
                    : "bg-white text-ink shadow-soft border border-ink/5"
                }`}
              >
                <span
                  className={`text-2xl transition-transform duration-200 ${
                    on ? "scale-110" : "scale-100"
                  }`}
                >
                  {interest.emoji}
                </span>
                <span
                  className={`text-[11px] font-semibold leading-tight text-center ${
                    on ? "text-white" : "text-ink/80"
                  }`}
                >
                  {interest.label}
                </span>
                {on && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-white/25 flex items-center justify-center animate-pop" key={animKey}>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 6L9 17l-5-5" />
                    </svg>
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {selected.length > 0 && (
          <div className="mt-6 animate-fade-up">
            <p className="text-xs text-ink/45 mb-2 font-medium">
              {selected.length} selected
            </p>
            <div className="flex flex-wrap gap-1.5">
              {selected.map((id) => {
                const i = INTERESTS.find((x) => x.id === id);
                return (
                  <span
                    key={id}
                    className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-pill bg-teal/15 text-teal border border-teal/25"
                  >
                    <span>{i.emoji}</span>
                    <span>{i.label}</span>
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] px-5 pb-6 pt-3 bg-gradient-to-t from-canvas via-canvas/95 to-transparent">
        <button
          onClick={() => canStart && onStart(selected)}
          disabled={!canStart}
          className={`w-full h-14 rounded-2xl font-heading font-bold text-base flex items-center justify-center gap-2 transition-all duration-200 ${
            canStart
              ? "bg-coral text-white shadow-card active:scale-[0.98]"
              : "bg-ink/10 text-ink/40"
          }`}
        >
          {canStart ? (
            <>
              Find my people
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </>
          ) : (
            "Pick at least one"
          )}
        </button>
      </div>
    </div>
  );
}
