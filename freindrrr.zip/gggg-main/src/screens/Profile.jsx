import React, { useState } from "react";
import { INTERESTS, interestById } from "../data";
import { InterestTag, Avatar, TopBar } from "../components";

export default function Profile({ profile, isMe, onSave, onBack, onSignOut }) {
  const [bio, setBio] = useState(profile.bio);
  const [lookingTo, setLookingTo] = useState(profile.lookingTo);
  const [interests, setInterests] = useState(profile.interests);
  const [editing, setEditing] = useState(false);

  const toggleInterest = (id) => {
    setInterests((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const save = () => {
    setEditing(false);
    onSave({ bio, lookingTo, interests });
  };

  const lookingOptions = [
    { id: "hang out", label: "Hang out", emoji: "👋" },
    { id: "collab", label: "Collab", emoji: "✨" },
    { id: "both", label: "Both", emoji: "🤝" },
  ];

  return (
    <div className="min-h-full bg-canvas">
      <TopBar
        title={isMe ? "Your profile" : "Profile"}
        onBack={isMe ? null : onBack}
        right={
          isMe ? (
            <button
              onClick={() => (editing ? save() : setEditing(true))}
              className="text-sm font-semibold text-coral px-3 py-1.5 rounded-pill hover:bg-coral/10 active:scale-95 transition"
            >
              {editing ? "Save" : "Edit"}
            </button>
          ) : null
        }
      />

      <div className="px-5 pt-6 pb-28 app-scroll overflow-y-auto">
        <div className="flex flex-col items-center text-center animate-fade-up">
          <Avatar src={profile.avatar} name={profile.name} size={96} ring />
          <h1 className="font-heading font-extrabold text-2xl text-ink mt-3">
            {isMe ? "You" : profile.name}
          </h1>
          <p className="text-sm text-ink/50 mt-0.5">
            {isMe ? "Freindrr member" : `${profile.distanceMi?.toFixed(1) ?? "—"} mi away`}
          </p>
        </div>

        <div className="mt-7">
          <h2 className="text-xs font-semibold text-ink/45 uppercase tracking-wider mb-2 px-1">
            About
          </h2>
          {editing ? (
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={140}
              rows={2}
              className="w-full bg-white rounded-2xl p-4 text-sm text-ink shadow-soft border border-ink/5 resize-none focus:outline-none focus:border-coral/40"
              placeholder="Write a line or two about yourself…"
            />
          ) : (
            <p className="bg-white rounded-2xl p-4 text-sm text-ink/80 leading-relaxed shadow-soft border border-ink/5">
              {bio}
            </p>
          )}
        </div>

        <div className="mt-6">
          <h2 className="text-xs font-semibold text-ink/45 uppercase tracking-wider mb-2 px-1">
            Looking to
          </h2>
          <div className="grid grid-cols-3 gap-2">
            {lookingOptions.map((opt) => {
              const active = lookingTo === opt.id;
              const disabled = !editing;
              return (
                <button
                  key={opt.id}
                  onClick={() => editing && setLookingTo(opt.id)}
                  disabled={disabled}
                  className={`rounded-2xl p-3 flex flex-col items-center gap-1 border transition-all duration-200 ${
                    active
                      ? "bg-coral text-white border-coral shadow-soft"
                      : "bg-white text-ink/70 border-ink/5"
                  } ${editing ? "active:scale-95" : "cursor-default"}`}
                >
                  <span className="text-lg">{opt.emoji}</span>
                  <span className="text-xs font-semibold">{opt.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-6">
          <h2 className="text-xs font-semibold text-ink/45 uppercase tracking-wider mb-2 px-1">
            Interests {isMe && `(${interests.length})`}
          </h2>
          {editing ? (
            <>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {interests.map((id) => {
                  const i = interestById(id);
                  return (
                    <button
                      key={id}
                      onClick={() => toggleInterest(id)}
                      className="inline-flex items-center gap-1 text-sm px-3 py-1.5 rounded-pill bg-coral text-white border border-coral active:scale-95 transition"
                    >
                      <span>{i.emoji}</span>
                      <span>{i.label}</span>
                      <span className="ml-0.5 text-xs">✕</span>
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-ink/40 mb-2">Tap to add</p>
              <div className="flex flex-wrap gap-1.5">
                {INTERESTS.filter((i) => !interests.includes(i.id)).map((i) => (
                  <button
                    key={i.id}
                    onClick={() => toggleInterest(i.id)}
                    className="inline-flex items-center gap-1 text-sm px-3 py-1.5 rounded-pill bg-white text-ink/70 border border-ink/10 active:scale-95 transition"
                  >
                    <span>{i.emoji}</span>
                    <span>{i.label}</span>
                    <span className="ml-0.5 text-xs text-teal">+</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {interests.map((id) => (
                <InterestTag key={id} id={id} />
              ))}
            </div>
          )}
        </div>

        {isMe && (
          <button
            onClick={onSignOut}
            className="mt-8 w-full h-12 rounded-2xl text-sm font-semibold text-ink/50 bg-white border border-ink/10 active:scale-[0.98] transition flex items-center justify-center gap-2"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" />
            </svg>
            Sign out
          </button>
        )}
      </div>
    </div>
  );
}
