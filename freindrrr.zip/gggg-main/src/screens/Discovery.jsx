import React, { useState, useMemo } from "react";
import { PEOPLE, ME, interestById } from "../data";
import { InterestTag, Avatar, EmptyState } from "../components";

export default function Discovery({ myInterests, connections, onConnect, onOpenProfile }) {
  const [filterOpen, setFilterOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("all");

  const cards = useMemo(() => {
    let list = PEOPLE.filter((p) =>
      p.interests.some((id) => myInterests.includes(id))
    );
    if (activeFilter !== "all") {
      list = list.filter((p) => p.interests.includes(activeFilter));
    }
    return list.sort((a, b) => a.distanceMi - b.distanceMi);
  }, [myInterests, activeFilter]);

  const sharedWithMe = (person) =>
    person.interests.filter((id) => myInterests.includes(id));

  const filterOptions = useMemo(() => {
    const ids = new Set();
    PEOPLE.forEach((p) =>
      p.interests.forEach((id) => myInterests.includes(id) && ids.add(id))
    );
    return Array.from(ids);
  }, [myInterests]);

  return (
    <div className="min-h-full bg-canvas">
      <header className="sticky top-0 z-20 bg-canvas/85 backdrop-blur-md border-b border-ink/5">
        <div className="px-5 pt-4 pb-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-ink/45 font-medium">Nearby people</p>
              <h1 className="font-heading font-extrabold text-2xl text-ink tracking-tight">
                Discover
              </h1>
            </div>
            <button
              onClick={() => setFilterOpen((v) => !v)}
              className={`w-10 h-10 flex items-center justify-center rounded-full transition active:scale-95 ${
                filterOpen || activeFilter !== "all"
                  ? "bg-coral text-white"
                  : "bg-white text-ink/70 shadow-soft border border-ink/5"
              }`}
              aria-label="Filter"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 6h16M7 12h10M10 18h4" />
              </svg>
            </button>
          </div>

          {filterOpen && (
            <div className="mt-3 flex flex-wrap gap-1.5 animate-fade-up">
              <FilterChip
                label="All"
                active={activeFilter === "all"}
                onClick={() => setActiveFilter("all")}
              />
              {filterOptions.map((id) => {
                const i = interestById(id);
                return (
                  <FilterChip
                    key={id}
                    label={`${i.emoji} ${i.label}`}
                    active={activeFilter === id}
                    onClick={() => setActiveFilter(id)}
                  />
                );
              })}
            </div>
          )}
        </div>
      </header>

      <div className="px-4 pt-3 pb-24 space-y-3.5 app-scroll overflow-y-auto">
        {cards.length === 0 ? (
          <EmptyState
            emoji="🧭"
            title="No one nearby yet"
            subtitle="Try widening your interests or check back soon — new people join every day."
          />
        ) : (
          cards.map((person, idx) => {
            const shared = sharedWithMe(person);
            const isPending = connections[person.id] === "pending";
            return (
              <article
                key={person.id}
                className="bg-white rounded-3xl p-4 shadow-card border border-ink/5 animate-fade-up"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div className="flex gap-3.5">
                  <button
                    onClick={() => onOpenProfile(person)}
                    className="shrink-0 active:scale-95 transition"
                  >
                    <Avatar src={person.avatar} name={person.name} size={64} />
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h2 className="font-heading font-bold text-[1.05rem] text-ink truncate">
                          {person.name}
                        </h2>
                        <div className="flex items-center gap-1 text-xs text-ink/50 mt-0.5">
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M12 21s-7-5.5-7-11a7 7 0 0114 0c0 5.5-7 11-7 11z" />
                            <circle cx="12" cy="10" r="2.5" />
                          </svg>
                          <span>{person.distanceMi.toFixed(1)} mi away</span>
                          <span className="text-ink/25">·</span>
                          <span>{person.lastActive}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-ink/70 mt-2 leading-snug line-clamp-2">
                      {person.bio}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-3">
                  {shared.slice(0, 3).map((id) => (
                    <InterestTag key={id} id={id} highlighted size="sm" />
                  ))}
                  {shared.length > 3 && (
                    <span className="text-xs text-ink/45 font-medium px-2 py-1">
                      +{shared.length - 3} more
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between mt-3.5 pt-3 border-t border-ink/5">
                  <p className="text-xs text-ink/45">
                    {shared.length} shared interest{shared.length !== 1 ? "s" : ""}
                  </p>
                  <button
                    onClick={() => onConnect(person.id)}
                    disabled={isPending}
                    className={`px-4 h-9 rounded-pill text-sm font-semibold flex items-center gap-1.5 transition-all duration-200 active:scale-95 ${
                      isPending
                        ? "bg-ink/5 text-ink/45"
                        : "bg-coral text-white shadow-soft hover:shadow-card"
                    }`}
                  >
                    {isPending ? (
                      <>
                        <span>Pending</span>
                        <span className="text-xs">⏳</span>
                      </>
                    ) : (
                      <>
                        Connect
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M5 12h14M13 6l6 6-6 6" />
                        </svg>
                      </>
                    )}
                  </button>
                </div>
              </article>
            );
          })
        )}
      </div>
    </div>
  );
}

function FilterChip({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`text-xs px-3 py-1.5 rounded-pill font-medium border transition active:scale-95 ${
        active
          ? "bg-coral text-white border-coral"
          : "bg-white text-ink/70 border-ink/10"
      }`}
    >
      {label}
    </button>
  );
}
