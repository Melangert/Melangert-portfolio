import React, { useState, useEffect } from "react";
import Onboarding from "./screens/Onboarding";
import Discovery from "./screens/Discovery";
import Profile from "./screens/Profile";
import Matches from "./screens/Matches";
import Auth from "./screens/Auth";
import { ME } from "./data";
import { supabase, getLocalSession, clearLocalSession } from "./supabaseClient";

const TABS = [
  {
    id: "discover",
    label: "Discover",
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? 2.4 : 2} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9" />
        <path d="M15.5 8.5l-2 5-5 2 2-5 5-2z" />
      </svg>
    ),
  },
  {
    id: "matches",
    label: "Inbox",
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? 2.4 : 2} strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
      </svg>
    ),
  },
  {
    id: "profile",
    label: "Profile",
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? 2.4 : 2} strokeLinecap="round" strokeLinejoin="round">
        <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
        <circle cx="12" cy="7" r="4" />
      </svg>
    ),
  },
];

export default function App() {
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [onboarded, setOnboarded] = useState(false);
  const [myInterests, setMyInterests] = useState(ME.interests);
  const [profile, setProfile] = useState(ME);
  const [tab, setTab] = useState("discover");
  const [connections, setConnections] = useState({});
  const [viewingProfile, setViewingProfile] = useState(null);

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => {
        setSession(data.session || getLocalSession());
      })
      .catch(() => setSession(getLocalSession()))
      .finally(() => setAuthReady(true));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const start = (selected) => {
    setMyInterests(selected);
    setProfile((p) => ({ ...p, interests: selected }));
    setOnboarded(true);
    setTab("discover");
  };

  const connect = (personId) => {
    setConnections((prev) => ({ ...prev, [personId]: "pending" }));
    // Simulate match acceptance after a short delay
    setTimeout(() => {
      setConnections((prev) => ({ ...prev, [personId]: "matched" }));
    }, 2200);
  };

  const saveProfile = (updates) => {
    setProfile((p) => ({ ...p, ...updates }));
    if (updates.interests) setMyInterests(updates.interests);
  };

  const signOut = async () => {
    clearLocalSession();
    try {
      await supabase.auth.signOut();
    } catch {
      /* network may be unavailable in sandbox */
    }
    setSession(null);
    setOnboarded(false);
    setTab("discover");
    setConnections({});
    setViewingProfile(null);
  };

  const openProfile = (person) => {
    setViewingProfile(person);
  };

  if (!authReady) {
    return (
      <Shell>
        <div className="min-h-screen flex items-center justify-center">
          <span className="w-7 h-7 border-2 border-coral/30 border-t-coral rounded-full animate-spin" />
        </div>
      </Shell>
    );
  }

  if (!session) {
    return (
      <Shell>
        <Auth
          onAuthed={(localSession) => {
            setSession(localSession);
          }}
        />
      </Shell>
    );
  }

  if (!onboarded) {
    return (
      <Shell>
        <Onboarding onStart={start} />
      </Shell>
    );
  }

  if (viewingProfile) {
    return (
      <Shell>
        <Profile
          profile={viewingProfile}
          isMe={false}
          onBack={() => setViewingProfile(null)}
        />
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="flex flex-col h-full">
        <div className="flex-1 min-h-0">
          {tab === "discover" && (
            <Discovery
              myInterests={myInterests}
              connections={connections}
              onConnect={connect}
              onOpenProfile={openProfile}
            />
          )}
          {tab === "matches" && (
            <Matches connections={connections} />
          )}
          {tab === "profile" && (
            <Profile profile={profile} isMe={true} onSave={saveProfile} onSignOut={signOut} />
          )}
        </div>

        <nav className="shrink-0 bg-white/95 backdrop-blur-md border-t border-ink/8 px-2 pt-1.5 pb-2">
          <div className="flex items-center justify-around">
            {TABS.map((t) => {
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className="flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-2xl transition active:scale-95"
                >
                  <span
                    className={`transition-colors duration-200 ${
                      active ? "text-coral" : "text-ink/40"
                    }`}
                  >
                    {t.icon(active)}
                  </span>
                  <span
                    className={`text-[10px] font-semibold transition-colors duration-200 ${
                      active ? "text-coral" : "text-ink/40"
                    }`}
                  >
                    {t.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </Shell>
  );
}

function Shell({ children }) {
  return (
    <div className="min-h-screen w-full bg-[#e9e6df] flex justify-center">
      <div className="relative w-full max-w-[430px] min-h-screen bg-canvas shadow-[0_0_40px_-10px_rgba(0,0,0,0.15)] overflow-hidden">
        {children}
      </div>
    </div>
  );
}
