/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "#F7F5F0",
        ink: "#1C1C1E",
        coral: "#FF5C35",
        teal: "#2EC4B6",
      },
      fontFamily: {
        heading: ['"Plus Jakarta Sans"', "sans-serif"],
        body: ['"Inter"', "sans-serif"],
      },
      boxShadow: {
        card: "0 6px 20px -8px rgba(28,28,30,0.18), 0 2px 6px -4px rgba(28,28,30,0.10)",
        soft: "0 2px 10px -6px rgba(28,28,30,0.15)",
      },
      borderRadius: {
        pill: "9999px",
      },
    },
  },
  plugins: [],
};
